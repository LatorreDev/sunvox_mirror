sunvox - version with 32bit (floating point) audio engine.
sunvox_lofi_console - version with 16bit (fixed point 4.12) audio engine for old and slow computers.
sunvox_multitouch - version with multitouch support; for Windows 7 and higher.