sunvox - version with 32bit (floating point) audio engine.
sunvox_lofi - version with 16bit (fixed point 4.12) audio engine for slow devices.

TOO LOW FPS?
1) add the "softrender" option to the SunVox config (~/.config/SunVox/sunvox_config.ini)
  OR
2) enable desktop OpenGL driver in the raspi-config.