Minimum system requirements for this version:
Linux (armel); ARMv7-A (Cortex-A8); glibc 2.5 (2006)