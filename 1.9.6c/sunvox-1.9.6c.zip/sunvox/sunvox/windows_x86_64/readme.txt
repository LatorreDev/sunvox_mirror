sunvox.exe - version for modern CPU.
sunvox_for_old_cpu.exe - version for old CPUs without SSSE3 support.