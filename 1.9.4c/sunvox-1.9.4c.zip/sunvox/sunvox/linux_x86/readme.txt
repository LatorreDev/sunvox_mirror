sunvox - high quality version with 32bit (floating point) audio engine.
sunvox_lofi - version with 16bit (fixed point 4.12) audio engine for old and slow computers.
